export { default as HeaderPrismic } from "./HeaderPrismic";
export { default as HomepageBanner } from "./HomepageBanner";
export { default as FooterPrismic } from "./FooterPrismic";
