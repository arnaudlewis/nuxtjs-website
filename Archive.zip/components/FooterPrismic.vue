<template>
  <footer class="footer">
    <a href="https://prismic.io" target="_blank" rel="noopener">
      <img class="logo" src="../assets/img/prismic-logo.svg" alt="Prismic">
    </a>
  </footer>
</template>

<script>
export default {
  name: 'FooterPrismic'
}
</script>

<style lang="sass" scoped>
.footer
  padding: 40px 0
  margin: 0 auto
  text-align: center
  border-top: 1px solid #DADADA

.logo
  width: 100px
</style>
